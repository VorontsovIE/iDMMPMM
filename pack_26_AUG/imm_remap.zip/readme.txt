Coordinates are given according to (April 2004, dm2, dmel40) genome release.
Sites are remapped using AUG_26_2009 iDMMPMM release: line.imb.ac.ru/iDMMPMM
Flanking regions length is selected as the smallest available footprint length minus one.

sites/ - remapped sites coordinates in small-BiSMark format
map/ - footprints with flanking regions with marked remapped sites
idmmpmm_sites.gff3 - 'sites/' in GFF format