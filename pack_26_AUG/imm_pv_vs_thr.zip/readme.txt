Here one can find P-value vs threshold curves computed for iDMMPMM_26_AUG motifs (taking all 'imm'-motifs with length < 14).

All curves are computed by AhoPro software starting from the threshold defined by the best possible PWM score.
Threhold step for graph was set to 0.1, upper P-value border was also set to 0.1
We used sequence length equal to motif size * 3 - 2 to account for possible motif self-overlapping.
Background distribution was taken from Drosophila genome (dm2, April 2004, dmel40).